#!/bin/bash

OBSERVER_CONF="observer.conf"
OBSERVER_LOG="observer.log"
if [ ! -f "$OBSERVER_CONF" ]; then
	echo "ERROR file not found" >> "$OBSERVER_LOG"
	exit 1
fi
while IFS= read -r script_name || [ -n "$script_name" ]; do
	if [[ -z "$script_name" || " $script_name" =~ ^[[:space:]]*# ]]; then
		continue
	fi
	script_name=$(echo "$script_name" | xargs)
	if ! pgrep -f "$script_name" > /dev/null 2>&1; then
		nohup "./$script_name" > /dev/null 2>&1 &
		echo "Started $script_name" >> "$OBSERVER_LOG"
	fi
done < "$OBSERVER_CONF"
